---
layout: post
title: 【五条人士多店】老虎包梦幻再版
date: 2020-09-25 14:00
thumbnail: 20200925-wutiaostore-tiger-s.jpg
tags:
 - 商务广告
 - 乐队周边
related:
 - url: https://item.taobao.com/item.htm?id=627987665280
   title: 五条人老虎包
 - url: https://item.taobao.com/item.htm?id=629072007420
   title: 五条人今日全球化明日自己耍海报
---

**原文**： [2020-9-23 五条人士多店的微博](https://weibo.com/7493731962/JlZMj8X3C) \| [2020-9-26 五条人士多店的微博](https://weibo.com/7493731962/JmreYgq8i)


**五条人士多店**  
*2020-9-23 20:57 来自 iPhone客户端 已编辑*

今日全球化，明日自己耍！大戏即将开演，梦幻丽莎士多店也将空降阿那亚海滩（具体位置与时间请见图1）。届时将有威震江湖绝版已久的“老虎包”梦幻再版限量发售🐯五条人《故事会》LP也将在士多店隆重首发🎵其中彩胶版为限量特别版，每人限购1张。
更多猛货，请来现场发掘！9月25日下午两点，阿那亚海滩见！
![](https://wx2.sinaimg.cn/mw690/008b8W0yly1gj0yk9xiegj315o1o0qv5.jpg)

**五条人士多店**  
*2020-9-26 18:52 来自 iPhone XS Max 已编辑*

老虎包已正式上架，现货发售，欢迎前往淘宝搜索店铺“五条人士多店”[奥特曼]🐯 

![](https://wx1.sinaimg.cn/mw1024/008b8W0yly1gj48vesykng30fa0mbu0x.gif)

## 商品展示

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN01icSnGj2FER11LObAs_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i1/2208814128848/O1CN01fm2t3x2FER11ym51k_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i4/2208814128848/O1CN01ma4DyV2FER10Txa3G_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN01xupRKO2FER11LPP75_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i4/2208814128848/O1CN01jIuo9W2FER0zVicQX_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN01ok9qYE2FER11LNf4D_!!2208814128848.jpg)

## 海报上新
**原文:** [五条人士多店的微博](https://weibo.com/7493731962/JooTJ5x8F)

**五条人士多店**  
*2020-10-9 16:34 来自 iPhone XS Max*

此款海报纸质印刷版已偷偷上架淘宝“五条人士多店”[奥特曼]少量印制。

> @张晓舟
> 
> 一张经典海报。设计: @左撇胡子 。这个新版又做了纹理褶皱的处理，完美。已出纸质。珍藏。 ​​​​

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN019M8E3E2FER0zXcPgK_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN01uewNHO2FER17BN1cB_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i4/2208814128848/O1CN015krN3v2FER120JydU_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i1/2208814128848/O1CN0129V7RD2FER17B8rHt_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i3/2208814128848/O1CN01Db8fax2FER17WmkBS_!!2208814128848.jpg)
