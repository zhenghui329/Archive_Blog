---
layout: post
title: 【五条人 × 拉面说】不打烊拉面馆：五条人给你来电
date: 2020-09-26 19:40
thumbnail: 20200926-noodleTalk-s.jpg
tags:
 - 商务广告
 - 广告片
---

**原文**： [2020-9-29 五條人WUTIAOREN的微博](https://weibo.com/1767922590/JmTY0thlu)

**五條人WUTIAOREN**  
*2020-9-29 20:00 来自 微博 weibo.com*

\#不打烊拉面馆#夜晚很安静，总适合去做些自己的事情，比如看书、观影、玩音乐，当然还有吃碗热气腾腾的拉面！

今晚阿面爱上阿条，我们和@拉面说 联名的#睡不着拉面#也已正式开售！三款经典口味融合我们的独家“深夜品味”，还有限定包装。希望给“晚睡艺术家”们带来更多的安慰与满足，大家可以去拉面说的店铺看看，获得我们的同款口味。

别忘了点开下面的视频，接听我们的来电。说不定，我们还会在某个深夜打电话给你，反正我们也睡不着。

[不打烊拉面馆五条人给你来电](https://www.bilibili.com/video/BV1jT4y1K7jB?p=21)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=928718110&bvid=BV1jT4y1K7jB&cid=284783962&page=21" frameborder="no" allowfullscreen="true"></iframe></div>

* [不打烊拉面馆采访](https://www.bilibili.com/video/BV13a4y1L7gC)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=669933433&bvid=BV13a4y1L7gC&cid=243838971&page=1" frameborder="no" allowfullscreen="true"></iframe></div>

* 拉面说 × 五条人: 睡不着拉面 \| [原文](https://weibo.com/5925214197/JmrSQ8nEs)

![](https://wx1.sinaimg.cn/mw1024/006sZASVly1gj4bbfgee3j33cx1sex6s.jpg)

![](https://wx1.sinaimg.cn/mw1024/006sZASVly1gj4bbgzpthj31t22pg7wl.jpg)

![](https://wx1.sinaimg.cn/mw1024/006sZASVly1gj4bbdlqg2j31t22pge85.jpg)

![](https://wx4.sinaimg.cn/mw1024/006sZASVly1gj4bbict40j31t22pgkjo.jpg)

* [宣传视频](https://www.bilibili.com/video/BV1jT4y1K7jB?p=22) \| [原文](https://weibo.com/5925214197/JoxprqNjZ)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=928718110&bvid=BV1jT4y1K7jB&cid=286215493&page=22" frameborder="no" allowfullscreen="true"></iframe></div>
