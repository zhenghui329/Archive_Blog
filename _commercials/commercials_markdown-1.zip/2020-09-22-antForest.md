---
layout: post
title: 【五条人 × 蚂蚁森林】世界无车日：有空一起坐地铁
date: 2020-09-22 10:30
thumbnail: 20200922-forest-s.jpg
tags:
 - 商务广告
---

**原文**： [2020-9-22 五條人WUTIAOREN的微博](https://weibo.com/1767922590/JlMf9A4Sj)

**五條人WUTIAOREN**  
*2020-9-22 10:30 来自 微博 weibo.com*

922世界无车日，有空一起坐地铁，做个真正的低碳青年也不错。@蚂蚁森林 ​​​​

![](https://wx1.sinaimg.cn/mw1024/69605b9egy1giy2tkhtn6j20ku112gsu.jpg)

* [宣传视频](https://www.bilibili.com/video/BV1jT4y1K7jB?p=19) \| [原文](https://weibo.com/6226754317/JlMgTqjGU)

<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=928718110&bvid=BV1jT4y1K7jB&cid=286215489&page=19" frameborder="no" allowfullscreen="true"></iframe></div>