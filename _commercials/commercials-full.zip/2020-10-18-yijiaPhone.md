---
layout: post
title: 【五条人 × 文淇 × 一加手机】五条人为一加手机发电：致敬王家卫、韦斯安德森、昆汀
date: 2020-10-18 20:30
thumbnail: 20201018-yijia-s.jpg
tags:
 - 商务广告
 - 广告片
 - 品牌活动
---

**原文**： [2020-10-18 五條人WUTIAOREN的微博](https://weibo.com/1767922590/JpN5qhdR2) \| [2020-10-19 五條人WUTIAOREN的微博](https://weibo.com/1767922590/JpTn6jzVW)

**五條人WUTIAOREN**  
*2020-10-18 20:00 来自 OnePlus 8T*

作为电影爱好者能和实力派演员@演员文淇 一起飙戏，而且一次过飙了三幕戏，真的很开心，这次跟文淇妹妹学到了很多东西，演戏也需要节奏感的。感谢@一加手机 给了这个机会——邀请我们来到#120Hz电力剧场#  
演得好不好你们来说，但我们是戏瘾过足，电力满格。另外据说，本片宜用#一加8T#120Hz高刷瞳孔屏看，才能看清我们充满细节的演技📽  
*网页链接*  
#文淇五条人用演技发电##天猫小黑盒#

### 一加手机120Hz电力剧场

[**电力剧场预告片**](https://www.bilibili.com/video/BV1jT4y1K7jB?p=35) \| [原文](https://weibo.com/3871046669/JptrL1ucG)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=928718110&bvid=BV1jT4y1K7jB&cid=284778536&page=35" frameborder="no" allowfullscreen="true"></iframe></div>

[**300秒**](https://www.bilibili.com/video/BV13K411A7kZ)  
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=499966781&bvid=BV13K411A7kZ&cid=246908977&page=1" frameborder="no" allowfullscreen="true"></iframe></div>

[**充电餐厅指南**](https://www.bilibili.com/video/BV1DK4y1h7qJ)  
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=884965972&bvid=BV1DK4y1h7qJ&cid=246910566&page=1" frameborder="no" allowfullscreen="true"></iframe></div>

[**还撑得住**](https://www.bilibili.com/video/BV1Fz4y1o7bb)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=584913943&bvid=BV1Fz4y1o7bb&cid=246911053&page=1" frameborder="no" allowfullscreen="true"></iframe></div>

![](http://mmbiz.qpic.cn/mmbiz/TEE21T5ibUlpZVsRA5GQofengZhG0dcljHOgD3J7SjJ7Gtn8z4Bby7ksd46rQloZ3A00vlr9dlhK5ZUKFBziba9g/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)

### 海报

![](https://wx4.sinaimg.cn/mw1024/004dYw4Bly1gjqz4vfk2hj60u01aux6s02.jpg)
*[原图](https://weibo.com/3871046669/JpqySBSHP)*

![](https://wx2.sinaimg.cn/mw1024/004dYw4Bgy1gjubgzzk4zj60u01auhdv02.jpg)
*[原图](https://weibo.com/3871046669/JpSYK30Zu)*

[原文](https://weibo.com/3871046669/JpJYxow7m)
![](https://wx2.sinaimg.cn/mw1024/004dYw4Bgy1gjtcssj5xbj60u01auqv702.jpg)

![](https://wx4.sinaimg.cn/mw1024/004dYw4Bgy1gjtcstv6rij60u01b67wo02.jpg)

![](https://wx3.sinaimg.cn/mw1024/004dYw4Bgy1gjtcssl8coj60u01b6x6r02.jpg)

![](https://wx4.sinaimg.cn/mw1024/004dYw4Bgy1gjtcu0eal7j60ge0pr7wh02.jpg)

![](http://mmbiz.qpic.cn/mmbiz/TEE21T5ibUlpZVsRA5GQofengZhG0dcljHOgD3J7SjJ7Gtn8z4Bby7ksd46rQloZ3A00vlr9dlhK5ZUKFBziba9g/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)

### 直播

**五條人WUTIAOREN**  
*2020-10-19 12:00 来自 OnePlus 8T*

昨天看了我们的电影，今晚来看我们的直播吧！作为#一加8T#电力大使，保证全力发电，陪你聊到尽兴，可能还有些@一加手机 和我们准备的大礼可期。*今晚8点半，记得准时来看*，直播间指路：*网页链接*  
#五条人来发电##天猫小黑盒##烈儿直播间# ​​​ ​​​​

[**直播预告：如何做到又真实又洒脱？**](https://www.bilibili.com/video/BV1jT4y1K7jB?p=38) \| [原文](https://weibo.com/3871046669/JpKJjncfh)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=928718110&bvid=BV1jT4y1K7jB&cid=284784194&page=38" frameborder="no" allowfullscreen="true"></iframe></div>

[**一加手机直播**](https://www.bilibili.com/video/BV1jT4y1K7jB?p=37)
注: 五条人在直播开头表演了《含叭哩细》和《鲜花在岸上开》
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=928718110&bvid=BV1jT4y1K7jB&cid=286277375&page=37" frameborder="no" allowfullscreen="true"></iframe></div>




