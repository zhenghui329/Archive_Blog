---
layout: post
title: 【五条人士多店】开业大吉
date: 2020-08-31 21:26
thumbnail: 20200902-wutiaostore-s.jpg
tags:
 - 商务广告
 - 乐队周边
related:
 - url: https://item.taobao.com/item.htm?id=625515124407
   title: 五条人塑料袋T恤
 - url: https://item.taobao.com/item.htm?id=625884801427
   title: 五条人疯马T恤
 - url: https://item.taobao.com/item.htm?id=626478299334
   title: 五条人塑料袋徽章
 - url: https://item.taobao.com/item.htm?id=626549543616
   title: 五条人回到海丰系列海报
 - url: https://item.taobao.com/item.htm?id=626026609078
   title: 五条人巡演系列海报
 - url: https://item.taobao.com/item.htm?id=627669590052
   title: 五条人向后看向前走线上音乐会海报
---

**原文**： [2020-8-31 五條人WUTIAOREN的微博](https://weibo.com/1767922590/Jiv8B6vGU) \| [2020-8-31 五条人士多店的微博](https://weibo.com/7493731962/JiuKoFisQ)


**五條人WUTIAOREN**  
*2020-8-31 21:26 来自 iPhone 6s*

欢迎光临👏

> @五条人士多店
>
> 五条人士多店今日开业大吉！ 官方形象代言人仁科阿茂酷帅代言，第一批猛货现已上架：经典红色塑料袋黑T恤、疯马绿T恤；五色塑料袋小徽章；以及五条人巡演系列海报、回到海丰系列海报。第二批猛货——三款人字拖及经典老虎包尚在制作中，敬请期待。士多店链接：[网页链接](https://shop565898707.taobao.com/)

![](https://wx4.sinaimg.cn/mw1024/008b8W0ygy1gia9lqbwtoj30rs12w1kx.jpg)

![](http://mmbiz.qpic.cn/mmbiz/TEE21T5ibUlpZVsRA5GQofengZhG0dcljHOgD3J7SjJ7Gtn8z4Bby7ksd46rQloZ3A00vlr9dlhK5ZUKFBziba9g/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)

## 商品展示

#### 经典红色塑料袋黑T恤
![](https://wx3.sinaimg.cn/mw1024/008b8W0ygy1gia9lpf7xcj30rs2zn7wh.jpg)

#### 疯马绿T恤
![](https://wx3.sinaimg.cn/mw1024/008b8W0ygy1gia9lr9ly9j30rs2znhdt.jpg)

#### 五色塑料袋小徽章
![](https://wx2.sinaimg.cn/mw1024/008b8W0ygy1gia9lsh56aj30rs2wwkjl.jpg)

#### 海报
![](https://wx4.sinaimg.cn/mw1024/008b8W0ygy1gia9lu4onbj30rs2zc7wk.jpg)

![](http://mmbiz.qpic.cn/mmbiz/TEE21T5ibUlpZVsRA5GQofengZhG0dcljHOgD3J7SjJ7Gtn8z4Bby7ksd46rQloZ3A00vlr9dlhK5ZUKFBziba9g/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)

### 回到海丰系列海报  
共8款/A3大小(约280mm×420mm)/157克特种纸四色印刷

![](https://img.alicdn.com/imgextra/i4/2208814128848/O1CN01AmsLSM2FER13HyULY_!!2208814128848.jpg)

![](https://gd2.alicdn.com/imgextra/i1/2208814128848/O1CN01j5EqrD2FER0ddQvZz_!!2208814128848.jpg)

### 巡演系列海报

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN01L7Yuxu2FER0fbSuxt_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i3/2208814128848/O1CN01AXN4EH2FER0y8cmJR_!!2208814128848.jpg)

![](https://gd2.alicdn.com/imgextra/i3/2208814128848/O1CN01xbpSmZ2FER0UDeCY9_!!2208814128848.jpg)

![](http://mmbiz.qpic.cn/mmbiz/TEE21T5ibUlpZVsRA5GQofengZhG0dcljHOgD3J7SjJ7Gtn8z4Bby7ksd46rQloZ3A00vlr9dlhK5ZUKFBziba9g/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)

## 士多店入口
![](https://wx3.sinaimg.cn/mw690/008b8W0ygy1gia9luut29j30rs12wn0x.jpg)

## 海报上新
**原文:** [五条人士多店的微博](https://weibo.com/7493731962/Jl4E5tCDE)

**五条人士多店**  
*2020-9-17 19:30 来自 iPhone客户端*

今晚七点半五条人首次线上音乐会直播；官方演出海报同时上线士多店[奥特曼]海报由严明实地拍摄，四条靓仔本色出演，胡子设计。尺寸比之前售卖的海报大一倍，采用140克特种纸，四色+专色印刷。淘宝搜索店铺：五条人士多店。[鲜花] ​​​​

![](https://img.alicdn.com/imgextra/i4/2208814128848/O1CN01pKbVRL2FER0tYZJbg_!!2208814128848.jpg)

![](https://wx3.sinaimg.cn/mw1024/008b8W0ygy1gitvcz3ofjj331z4wc4qr.jpg)

![](https://wx2.sinaimg.cn/mw1024/008b8W0ygy1gitvd475z3j34e62xl4r6.jpg)

![](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1gitvfsnyvtj34h42zk7wy.jpg)

![](https://wx2.sinaimg.cn/mw1024/008b8W0ygy1gitvcv0rlqj324x2uku0x.jpg)

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN01DDSJPc2FER0qozB99_!!2208814128848.jpg)
