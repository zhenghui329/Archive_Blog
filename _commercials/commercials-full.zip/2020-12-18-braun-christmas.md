---
layout: post
title: 【五条人 × 博朗】圣诞直播
date: 2020-12-18 17:00
thumbnail: 20201218-christmas-s.jpg
tags:
 - 商务广告
 - 品牌活动
---

**原文**： [2020-12-18 五條人WUTIAOREN的微博](https://weibo.com/1767922590/Jz10UEKjf)  

**五條人WUTIAOREN**  
*2020-12-18 12:00 来自 微博 weibo.com*

OK！难得今天，天气晴朗，我们骑马过河，出发！不知道天上有几朵云，也不知道我们有多少粉丝？只知道下午5点 ，我们会和@德国博朗Braun 一起做直播，给大家送上一些圣诞小礼物。记得打开手机@天猫App ，带井号搜索#博朗圣诞礼盒#，领取我们发给你的红包。领完红包看直播，perfect！#每周大牌日# *【圣诞礼盒】博朗小猎豹5系M4200cs设计师礼盒...*

### 直播  

[**直播预告**](https://www.bilibili.com/video/BV1jT4y1K7jB?p=31) \| [原文](https://weibo.com/1767922590/Jz10UEKjf)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=928718110&bvid=BV1jT4y1K7jB&cid=284784955&page=31" frameborder="no" allowfullscreen="true"></iframe></div>

[**博朗直播**](https://www.bilibili.com/video/BV1jT4y1K7jB?p=32)  
五条人演唱：《春天小姐》《有所追求》
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=928718110&bvid=BV1jT4y1K7jB&cid=286279467&page=32" frameborder="no" allowfullscreen="true"></iframe></div>

### 宣传图

![](https://wx4.sinaimg.cn/mw1024/7a3b0f4ely1glrz50drwzj20ku112arx.jpg)
*[原文](https://weibo.com/2050690894/Jz1QqlA6x)*

### 官方照片

[原文](https://weibo.com/2050690894/Jztiwvtb1)

![](https://wx4.sinaimg.cn/mw690/7a3b0f4ely1glvbp8x166j22yo1z41j0.jpg)

![](https://wx2.sinaimg.cn/mw690/7a3b0f4ely1glvbp9lzgwj22yo1z47wh.jpg)

![](https://wx1.sinaimg.cn/mw690/7a3b0f4ely1glvbpa72ukj22yo1z4x1f.jpg)

![](https://wx1.sinaimg.cn/mw690/7a3b0f4ely1glvbpbjgo7j22yo1z4u0x.jpg)

![](https://wx2.sinaimg.cn/mw690/7a3b0f4ely1glvbpdjn3aj22xo1ygb29.jpg)
*仁科的一笔画你画我猜：毛线*

[原文](https://weibo.com/1746683291/Jzb3pbFNV)

![](https://wx4.sinaimg.cn/mw690/681c459bgy1glt3qthg2ij20u00k0n11.jpg)

![](https://wx3.sinaimg.cn/mw690/681c459bgy1glt3r5a3caj22yo1z41jz.jpg)

![](https://wx3.sinaimg.cn/mw690/681c459bgy1glt3rlxsznj22yo1z4x58.jpg)

![](https://wx1.sinaimg.cn/mw690/681c459bgy1glt3qxs4rwj22yo1z4kg6.jpg)

![](https://wx3.sinaimg.cn/mw690/681c459bgy1glt3r1esofj22yo1z41kx.jpg)
*仁科的一笔画：疯马*

**来自博主：這個那個點點** [原文](https://weibo.com/1802770170/JzjmiCiM5)  

![](https://ww2.sinaimg.cn/mw1024/6b7416fagy1glu4gat9byj22yo1z4dw7.jpg)

![](https://ww1.sinaimg.cn/mw1024/6b7416fagy1glu4gbe09vj22yo1z4k51.jpg)

![](https://ww2.sinaimg.cn/mw1024/6b7416fagy1glu4gcp8nhj22y01yo1kx.jpg)

![](https://wx4.sinaimg.cn/mw1024/6b7416fagy1glse9xiszxj20u0140gs2.jpg)
*仁科的一笔画：阿茂*

**暂未找到原文链接**

![](https://wx1.sinaimg.cn/mw1024/005PjUkDly1gnf2nsr88pj32yo1z47wh.jpg)

![](https://wx2.sinaimg.cn/mw1024/005PjUkDly1gnf2nu0yevj32yo1z4kjl.jpg)

