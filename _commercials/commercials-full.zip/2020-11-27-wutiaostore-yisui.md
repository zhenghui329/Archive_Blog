---
layout: post
title: 【五条人士多店 × 艺穗町】深圳湾艺穗节开设五条人快闪店
date: 2020-11-27 08:00
thumbnail: 20201127-wutiaostore-yisui-s.jpg
tags:
 - 商务广告
 - 乐队周边
---

**原文**： [2020-11-27 五條人WUTIAOREN的微博](https://weibo.com/1767922590/JvSNL56bR) \| [2020-11-27 五条人士多店的微博](https://weibo.com/7493731962/JvRpfDA0R) \| [2021-1-4 五条人士多店的微博](https://weibo.com/7493731962/JBEruhtBa)

**五條人WUTIAOREN**  
*2020-11-27 21:34*

Wutiaoren Store is opened in Shenzhen, welcome to visit!

> @五条人士多店
> 
> 五条人士多店，实体快闪店在深圳的街头——南头古城——开张了！这也是2020年度@深圳湾艺穗节 艺穗町的内容之一，“人人艺术，处处舞台”一直是艺穗节十年坚守的信念，这与@五条人wutiaoren  的理念不谋而合。五条人的周边不仅仅是周边，它往往就是乐队美学理念的化身。这家深圳实体店还有《故事会》的黑胶和绿胶售卖。同时还有一个小型的五条人视觉原作展——仁科手绘单曲封面原作、《故事会》专辑封面原作……11月27日（今日）晚上六点开张营业，欢迎光临！[来]快闪时间：2020.11.27—2021.1.3。营业时间：上午十点——晚上九点（周一闭馆），地址详见[图9](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1gl3vvww7zkj30mx2uswlu.jpg)。

![](https://wx4.sinaimg.cn/mw1024/008b8W0ygy1gl3vzujszrj30wt19x7wi.jpg)

![](https://wx3.sinaimg.cn/mw1024/008b8W0ygy1gl3vvrm0naj31ma2ff7wi.jpg)

![](https://wx2.sinaimg.cn/mw1024/008b8W0ygy1gl3vvzczq5j32gw1n9x6p.jpg)

![](https://wx4.sinaimg.cn/mw1024/008b8W0ygy1gl3vvw5w9kj32gw1n9x6p.jpg)

![](https://wx4.sinaimg.cn/mw1024/008b8W0ygy1gl3vvh2ar6j32gw1n91ky.jpg)

![](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1gl3vvk27paj32gw1n94qq.jpg)

![](https://wx4.sinaimg.cn/mw1024/008b8W0ygy1gl3vvn36ilj31n92gwkjm.jpg)


![](http://mmbiz.qpic.cn/mmbiz/TEE21T5ibUlpZVsRA5GQofengZhG0dcljHOgD3J7SjJ7Gtn8z4Bby7ksd46rQloZ3A00vlr9dlhK5ZUKFBziba9g/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)


**五条人士多店**  
*1月4日 20:03 来自 iPhone XS Max*

为期一个月的五条人士多快闪店昨日完美收摊。非常感谢光临士多店的朋友，我们每天都能从后台看到你们精彩的repo；感谢主办方@深圳湾艺穗节 邀请。新的一年士多店将会去到更多的地方，期待你的下次光临。祝大家新年快乐[爱你] ​​​​ 

![](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1gmbwv3nuz7j31k62c9kjl.jpg)

![](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1gmbwv5dy0oj31li2e97wi.jpg)



