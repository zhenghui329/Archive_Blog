---
layout: post
title: 【五条人士多店 × 南坡秋兴】线下实体店
date: 2020-10-26 16:00
thumbnail: 20201026-wutiaostore-nanpo-s.jpg
tags:
 - 商务广告
 - 乐队周边
related:
 - url: https://item.taobao.com/item.htm?id=631161791902
   title: 五条人南方夜色四城巡演海报
---

**原文**： [2020-10-26 五條人WUTIAOREN的微博](https://weibo.com/1767922590/Jr0RTtutz) \| [2020-10-26 五条人士多店的微博](https://weibo.com/7493731962/JqYX1lZAC)

**五條人WUTIAOREN**  
*2020-10-26 20:55*

“五条人士多”的第一家实体店，在中国河南，修武县西村乡，大南坡村。欢迎光临👏

> @五条人士多店
> 
> 五条人士多店首家线下专柜，将于10月30日正式营业，位于河南省焦作市修武县西村乡大南坡村，碧山工销社（焦作店）内，也是此次“南坡秋兴”活动的一部分。由@左靖  策划的大南坡计划是一个涵盖了美学实践、自然教育、社会美育、地方营造、建筑景观与展览实践、产品与空间创新等各种活跃动能的联合体。五条人将继续支持这一乡村艺术实践，并从中学习。详情了解：*南坡秋兴 2020 活动发布 \| GSS Autumn Gather...*

![](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1gk2shnt663j32t71vgx6q.jpg)

![](https://wx4.sinaimg.cn/mw1024/008b8W0ygy1gk2shjnaunj31rl19f7wh.jpg)

![](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1gk2shooye7j31gd21bu0x.jpg)

![](https://wx2.sinaimg.cn/mw1024/008b8W0ygy1gk2shm742lj30zk1r9kj2.jpg)

![](http://mmbiz.qpic.cn/mmbiz/TEE21T5ibUlpZVsRA5GQofengZhG0dcljHOgD3J7SjJ7Gtn8z4Bby7ksd46rQloZ3A00vlr9dlhK5ZUKFBziba9g/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)

## 海报上新
**原文:** [五条人士多店的微博](https://weibo.com/7493731962/JswNjdeMM)

**五条人士多店**  
*2020-11-5 20:02 来自 iPhone XS Max 已编辑*

我们又又又偷偷上架了一张“南方夜色”巡演的纸质海报🌌  淘宝搜索店铺“五条人士多店”[来] ​​​​ 

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN01cPM5eZ2FER1QSnW7z_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i3/2208814128848/O1CN01gMihZO2FER1YJgjuV_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i1/2208814128848/O1CN01Ezlozt2FER1UtobbW_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN01GapyPe2FER1SgSSPc_!!2208814128848.jpg)

