---
layout: post
title: 【五条人士多店】“美总是古怪的”“道上靓仔”两款卫衣上架
date: 2020-12-11 15:21
thumbnail: 20201211-wutiaostore-beauty-s.jpg
tags:
 - 商务广告
 - 乐队周边
related:
 - url: https://item.taobao.com/item.htm?id=634131158168
   title: 五条人道上靓仔白色卫衣
 - url: https://item.taobao.com/item.htm?id=633814385679
   title: 五条人美总是古怪的湖蓝绿卫衣
 - url: https://item.taobao.com/item.htm?id=633182228745
   title: 五条人南方夜色福建巡演海报
---

**原文**： [2020-12-11 五條人WUTIAOREN的微博](https://weibo.com/1767922590/JxYln7PGf) \| [2020-12-15 五条人士多店的微博](https://weibo.com/7493731962/JyCbFjTdF) \| [2020-12-18 五条人士多店的微博](https://weibo.com/7493731962/Jz5bd952Z)

**五條人WUTIAOREN**  
*2020-12-11 15:21 已编辑*

拥有《故事会》专辑的朋友们，你们有没有注意到小册子上面印着那些名人名言，其中我们特意放上了波德莱尔的一句话：美总是古怪的。

这次我们把波德莱尔的这句话，用法语、英语、国语围成一个塑料袋，印在那件湖蓝绿卫衣背后。听起来是有那么一点古怪，但看上去是挺美的，不是吗？

凯鲁亚克的“on the road”——在路上的“垮掉的一代”，用我们的话来说就是——道上靓仔。废话讲完，无论是on the handsome road 还是on the pretty road，五条road，一条road走到黑[鲜花]

淘宝搜索店铺：五条人士多店。

### “美总是古怪的”卫衣

![](https://wx2.sinaimg.cn/mw1024/005PjUkDly1gnf2nlhvmxj30rs0jyn9j.jpg)

![](https://img.alicdn.com/imgextra/i3/2208814128848/O1CN01zR7qGj2FER27QXlmK_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i1/2208814128848/O1CN013y1An32FER27EPamK_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i4/2208814128848/O1CN01MQrQa12FER27ENyyn_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i1/2208814128848/O1CN01akI0c72FER26aj7H4_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i1/2208814128848/O1CN01Z5tv7x2FER22idK59_!!2208814128848.jpg)

### “道上靓仔”卫衣

![](https://img.alicdn.com/imgextra/i1/2208814128848/O1CN01dPlzFn2FER269iZty_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i3/2208814128848/O1CN017FpKve2FER269kJzP_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i3/2208814128848/O1CN01TxLtTT2FER2BAu1Oh_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i3/2208814128848/O1CN01GikCgT2FER2C3WcXK_!!2208814128848.jpg)

![](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1glot6dk3vlj30kq0vfqgx.jpg)

![](https://wx3.sinaimg.cn/mw1024/008b8W0ygy1glot6hc9zvj30np0zknbx.jpg)

![](https://img.alicdn.com/imgextra/i4/2208814128848/O1CN01EaPoHG2FER2C3W9Q6_!!2208814128848.jpg)


### 超级名模——胡子的猫

![](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1glsdtai9ctj31hx23hhdt.jpg)

![](http://mmbiz.qpic.cn/mmbiz/TEE21T5ibUlpZVsRA5GQofengZhG0dcljHOgD3J7SjJ7Gtn8z4Bby7ksd46rQloZ3A00vlr9dlhK5ZUKFBziba9g/640?wx_fmt=jpeg&tp=webp&wxfrom=5&wx_lazy=1&wx_co=1)


## 海报上新

**原文**：[2020-12-11 五条人士多店的微博](https://weibo.com/7493731962/Jy0vxcKcM)

**五条人士多店**  
*2020-12-11 20:52 来自 iPhone XS Max*

今天士多店上架的还有这张美丽漂亮英俊潇洒的海报[鲜花][鲜花] 

![](https://img.alicdn.com/imgextra/i4/2208814128848/O1CN01AIdX3a2FER27TFh0m_!!2208814128848.jpg)

![](https://wx1.sinaimg.cn/mw1024/008b8W0ygy1glk7hn59jkj315o15ohdt.jpg)

![](https://img.alicdn.com/imgextra/i1/2208814128848/O1CN01wNN3D42FER20sdYb5_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i4/2208814128848/O1CN01pIaqBy2FER29Nq7y4_!!2208814128848.jpg)

![](https://img.alicdn.com/imgextra/i2/2208814128848/O1CN01J9ix1m2FER1uyp4bW_!!2208814128848.jpg)



