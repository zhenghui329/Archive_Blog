---
layout: post
title: 【五条人 × 时尚先生】五条人的泳池派对
date: 2020-09-26 20:15
thumbnail: 20200926-pool-s.jpg
tags:
 - 商务广告
related:
 - url: https://weibo.com/1195397063/Jms4VtaqJ
   title: 先生专访 | 五条人：一半艺术家，一半流浪者
 - url: https://weibo.com/1195397063/JoAyfiYe7
   title: 先生专访 | 五条人：该尴尬就尴尬
---

### 泳池派对视频

[**泳池派对预告**](https://www.bilibili.com/video/BV1rN411d7Qa) \| [原文](https://weibo.com/1195397063/JmrukqpXm)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=501291784&bvid=BV1rN411d7Qa&cid=287213596&page=1" frameborder="no" allowfullscreen="true"></iframe></div>

[**泳池派对：十年水流动十年水流西**](https://www.bilibili.com/video/BV1rN411d7Qa?p=4) \| [原文](https://weibo.com/1195397063/JmrMB2K1x)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=501291784&bvid=BV1rN411d7Qa&cid=287213877&page=4" frameborder="no" allowfullscreen="true"></iframe></div>

[**泳池派对：蒙娜丽莎发廊**](https://www.bilibili.com/video/BV1rN411d7Qa?p=3) \| [原文](https://weibo.com/1195397063/JmrSGBueU)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=501291784&bvid=BV1rN411d7Qa&cid=287213766&page=3" frameborder="no" allowfullscreen="true"></iframe></div>

[**泳池派对采访**](https://www.bilibili.com/video/BV1rN411d7Qa?p=2) \| [原文](https://weibo.com/1195397063/JmrGvl0Gu)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=501291784&bvid=BV1rN411d7Qa&cid=287213667&page=2" frameborder="no" allowfullscreen="true"></iframe></div>

### 杂志拍摄  

[原文](https://weibo.com/1195397063/JjfGvwFGu)

![](https://wx2.sinaimg.cn/mw1024/001iTLnNly1gig0thm8akj62ve3qvx6q02.jpg)

![](https://wx2.sinaimg.cn/mw1024/001iTLnNly1gig0tmlt0lj62112lxkjl02.jpg)

![](https://wx2.sinaimg.cn/mw1024/001iTLnNly1gig0tjaxyyj61yn2lxb2902.jpg)

[原文](https://weibo.com/1195397063/Jms4VtaqJ)

![](https://wx1.sinaimg.cn/large/001iTLnNly4gj2ztzumq4j60u00khtd502.jpg)

![](https://wx4.sinaimg.cn/large/001iTLnNly4gj2ztzvfuwj60u00n0ada02.jpg)

![](https://wx3.sinaimg.cn/large/001iTLnNly4gj2ztzx96bj60u013478k02.jpg)

[原文](https://weibo.com/1195397063/JoAsayN0B)

![](https://wx4.sinaimg.cn/mw1024/001iTLnNly1gjkksqulbwj60rq10zkjl02.jpg)

![](https://wx1.sinaimg.cn/mw1024/001iTLnNly1gjkksqpn3ij611g0s344e02.jpg)

![](https://wx4.sinaimg.cn/mw1024/001iTLnNly1gjkksqosx2j60s311gjvx02.jpg)

![](https://wx4.sinaimg.cn/mw1024/001iTLnNly1gjkksqrlumj611g0s3dlj02.jpg)

![](https://wx4.sinaimg.cn/mw1024/001iTLnNly1gjkksqplybj60rb10fdiu02.jpg)

![](https://wx2.sinaimg.cn/mw1024/001iTLnNly1gjkkswez4nj611g0s3kae02.jpg)

![](https://wx3.sinaimg.cn/mw1024/001iTLnNly1gjkkswbv9dj611g0s379902.jpg)

![](https://wx3.sinaimg.cn/mw1024/001iTLnNly1gjkkt1hgd8j60s311ghdt02.jpg)

![](https://wx1.sinaimg.cn/mw1024/001iTLnNly1gjkkswabg7j60s311gwi602.jpg)

![](https://wx2.sinaimg.cn/mw1024/001iTLnNly1gjkkswcfzyj60s311gai502.jpg)

![](https://wx3.sinaimg.cn/mw1024/001iTLnNly1gjkksqpa10j60s311gtfm02.jpg)
