---
layout: post
title: 【五条人 × 天猫超市】天猫超市买菜日主题曲：《厨房的故事》
date: 2020-09-19 00:00
thumbnail: 20200919-kitchenStory-s.jpg
tags:
 - 商务广告
 - 广告歌
 - 品牌活动
related:
 - url: https://wutiaoren.info/songs/2020kitchen.html
   title: 试听及歌词
---

**原文**： [2020-9-20 五條人WUTIAOREN的微博](https://weibo.com/1767922590/JltAlsz0B)

**五條人WUTIAOREN**  
*2020-9-20 11:00 来自 微博 weibo.com*

今天发的是新歌不是新锅，K厨房的故事 。大家有什么问题，晚上21:00，淘宝直播搜@天猫超市 直播间，我们来唱歌，我们来聊聊。

### 直播

[**直播宣传**](https://www.bilibili.com/video/BV1Vf4y1D7BH)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=287132728&bvid=BV1Vf4y1D7BH&cid=237301127&page=1" frameborder="no" allowfullscreen="true"></iframe></div>

[**天猫超市直播间：《厨房的故事》新歌首发**](https://www.bilibili.com/video/BV1Dk4y1k7Ks)  
注：五条人现场表演
* 鲜花在岸上开
* 像将军那样喝酒
* 梦幻丽莎发廊
* 厨房的故事
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=754744427&bvid=BV1Dk4y1k7Ks&cid=238899367&page=1" frameborder="no" allowfullscreen="true"></iframe></div>

[**厨房的故事live cut**](https://www.bilibili.com/video/BV1Vv411y7SV)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=244745026&bvid=BV1Vv411y7SV&cid=238903332&page=1" frameborder="no" allowfullscreen="true"></iframe></div>

[**天猫超市小饭桌五条人吃播**](https://www.bilibili.com/video/BV1UV411m75H)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=414649862&bvid=BV1UV411m75H&cid=238901027&page=1" frameborder="no" allowfullscreen="true"></iframe></div>


### 广告新歌：《厨房的故事》

**9月19日零点独家上线虾米音乐**

![](https://wx3.sinaimg.cn/mw1024/c344f664ly1giv91c39elj25dl7777wx.jpg)
*[原图]((https://weibo.com/3276076644/JlfRNloH0)*

[**天猫超市新歌“厨房的故事”独家探班**](https://www.bilibili.com/video/BV1Vz4y1Z7sW)
<div class="iframe-container"><iframe class="responsive-iframe" src="//player.bilibili.com/player.html?aid=584626176&bvid=BV1Vz4y1Z7sW&cid=237303556&page=1" frameborder="no" allowfullscreen="true"></iframe></div>

[**独家探班照片**](https://weibo.com/3276076644/JleNAmNKY)

![](https://wx2.sinaimg.cn/mw1024/c344f664ly1giv4c7p29jj24mo334qv8.jpg)

![](https://wx2.sinaimg.cn/mw1024/c344f664ly1giv4c9lbfrj23344mox6s.jpg)

![](https://wx1.sinaimg.cn/mw1024/c344f664ly1giv4cb0ziij23344mo7wk.jpg)

![](https://wx3.sinaimg.cn/mw1024/c344f664ly1giv4ccfc1tj23344moe84.jpg)

![](https://wx2.sinaimg.cn/mw1024/c344f664ly1giv4cdr7lej23344mou10.jpg)

![](https://wx1.sinaimg.cn/mw1024/c344f664ly1giv4cf6c3mj21zk1bp7f0.jpg)



